# Artifact Package for the Maintenance-Study Paper

-------------------------------------------------------

## Overview and Description

This artifact package aims to make the analysis of our study reproducible.

In our study, we compared the maintenance effort involved when developers are given automatically generated or manually written tests.

A dedicated website was created to guide the participants through the study and to time their actions. The steps are as follows:

1. Users were randomly assigned unique participant IDs, which they entered on the homepage (see `screenshots/1_website_homepage.png`)
2. After entering their ID, participants were given a unique command to execute (see `screenshots/2_website_prepare.png`). Executing this command would launch an eclipse session with the CUT and the test for the CUT already open. Workspaces used for this step are in the `workspaces` folder.
3. After pressing Continue on step-2, participants were presented with a question to decide whether to fix code or test (see `screenshots/3_website_decision_page.png`)
4. After clicking a decision a confirmation box would be presented to avoid accidental clicks (see `screenshots/4_decision_confirmation.png`)
5. After a decision was made, participants were told whether their answer was correct, and were also given the _correct_ answer. They were then asked to make the fix (see `screenshots/5_fix_task.png`)
6. After implementing the fix, the participants would be then asked to upload their fix solution (see `screenshots/6_upload_fix.png`)
7. Once participants uploaded their solutions, they were either asked to continue to the next task/session (each participant performed two tasks, a code-fixing or test-fixing task, in random order), or to fill the survey after both sessions were completed (data for this is available in `data/survey.csv`). (see `screenshots/7_thank_you_page.png`)

Note: The participants were timed during this process (namely duration of making the decision, duration of creating a fixed solution, and overall duration), the data for which is available in `data/submissions.csv`.


To help with the replication of the study and future analyses of the data, we will be making the following data publicly available:

- Java Projects/Classes used in the study
- Golden tests and solutions
- Tests (the automatically generated and manual ones)
- Participants' submitted solutions
- The data collected about their submissions (e.g., timings, correctness of the solutions, etc.)
- Competency quiz questions used to select candidates

-------------------------------------------------------

## Package Contents

- `data`
    - `submissions.csv` : Data collected on individual submissions of the participants such as timings and correctness (150 records)
    - `survey.csv` : Survey response by the participants (75 records)
    - `test_correctness.csv` : The final result of automated & manual analysis of the participants' test fixes
    - `actions_zips.csv` : log of participants' actions (e.g., edits/executions)
    - `timeline.csv` : same data as actions_zips.csv measured through a different plugin (as a backup)
    - `rabbit` :
        - `fileEvent.csv` : time participants spent on each file
        - `launchEvent.csv` : IDE actions participants launched (e.g., using debugger, coverage)
- `r`
    - `main.R` : The main R script to analyse the data
    - `util.R` : A set of utilities main.R depends on
- `submissions`
    - 150 user submissions of code/test fixes
- `workspaces`
    - 8 workspaces used for our evaluation. The name of each workspace indicates the class, task and test type
- `golden`
    - `golden_code` : Contains the correct implementation of the buggy classes
    - `golden_test_suites` : Our golden test suites used to evaluate the correctness of the participants' code-fixes (besides our manual evaluation).
    - `testfix_solutions` : A model solution used to evaluate participants' test-fixes (besides our manual evaluation).
- `screenshots` : Screenshots of the decicated website used to conduct the human study
- `competency_quiz` : Screenshots of the quiz questions asked from the participants
- `run.sh` : Our single-run script to generate the figures/tables/macros for the paper
- `Dockerfile` : The `./run.sh` script relies on this (you can ignore this file).

-------------------------------------------------------

## Requirements

- **Operating system**: Although we've tested the scripts on Windows, Linux, and Mac, a unix environment is preferred (in either case, `bash` is required).
- **Docker**: Given that our R script relies on a number of scripts, to save time, we have prepared a docker image with the libraries pre-installed. While it's not _mandatory_ to have docker installed, having the latest version of docker installed and running is recommended.
- **R**: If you prefer not to use the Docker option, please make sure that a recent version of R is installed (>=3.3).

-------------------------------------------------------

## How to use

1. If you have Docker installed, please make sure that it is up and running (Please note that having Docker installed is not required, but is preferred) 
2. Simply execute the `./run.sh` script
    - NOTE: If you are not using Docker, please call the script as follows: `./run.sh nodocker`
    - NOTE: If you are using Windows, having GNU utilities installed is necessary to run this script, e.g., MSYS
3. On successful execution of the script, two directories will be created: `figures` , `generated_files`
4. From the `figures` directory, the boxplot figures correspond to the duration boxplots (Fig. 5 and 6), and the likert figures correspond to the two likert plots (Fig. 7) in the paper
5. From the `generated_files` directory, the macroFile.tex contains numerical values used in the paper that were automatically generated, and the tables correspond to the tables 2 and 3
6. The fix submissions in the `submissions` directory correspond to individual fixes participants uploaded.
    - NOTE: The files have been named according to the session key (`key` in the `data/submissions.csv`), type of fix, subject class, and the type of test given (manual or evosuite)
    - NOTE: You can use the corresponding Eclipse workspace to execute the fixes
7. From the `workspaces` directory, each archive contains a full Eclipse workspace (i.e. not project). These are the exact workspaces used to conduct the evaluation.
