#!/bin/bash

FIGDIR="figures"
GENDIR="generated_files"

[[ -d "$FIGDIR" ]] && /bin/rm -rf "$FIGDIR"
[[ -d "$GENDIR" ]] && /bin/rm -rf "$GENDIR"

nodocker=false
[[ ! -z "$1" ]] && [[ "$1" == "nodocker" ]] && nodocker=true

# Try to see if docker is installed
docker_exists=$(docker -v 2>&1)

if [ "$?" == "0" ] && [ "$nodocker" = false ]; then

	DOCKER_IMAGE_NAME="maintenance-artifact"
	DOCKER_CONTAINER_NAME="$DOCKER_IMAGE_NAME"

	### remove existing containers/images
	docker rmi -f "$DOCKER_IMAGE_NAME" > /dev/null 2>&1
	docker rm -f "$DOCKER_CONTAINER_NAME" > /dev/null 2>&1

	docker build -t $DOCKER_IMAGE_NAME .

	# If docker build failed
	if [ "$?" != "0" ]; then
		echo "!!!!!"
		echo "Docker build failed. Please check the error above and verify that docker is running fine. If you prefer to run the script without docker, re-run this script like the following: ./run.sh nodocker";
		exit 1
	fi

	docker run --name="$DOCKER_CONTAINER_NAME" "$DOCKER_IMAGE_NAME"

	# Copy back the generated figures/data
	docker cp $DOCKER_CONTAINER_NAME:/usr/local/src/artifacts/$FIGDIR .
	docker cp $DOCKER_CONTAINER_NAME:/usr/local/src/artifacts/$GENDIR .

else
	echo 
	echo "!!! Docker is not installed, trying to run the script directly with R !!!"
	echo "-------------------------------------------------------------------------"
	
	cd r
	Rscript main.R

	if [ "$?" != "0" ]; then
                echo "!!!!!"
                echo "The execution of the R script failed. This is likely due to an old R environment, insufficient permissions, or missing R packages. Try runing with 'sudo ./run.sh', or, please install Docker and re-run this script.";
                exit 1
        fi

	/bin/rm -f "Rplots.pdf"
	cd ..
	
	
fi


echo
echo "==========="
echo "Please check the '$FIGDIR' and '$GENDIR' directories."
echo "==========="
