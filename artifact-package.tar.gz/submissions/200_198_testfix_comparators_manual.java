package collections.comparators;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 *
 */
public class FixedOrderComparatorTest {

	@Test
	public void test() {
		try {
			Object[] emptyArray = {};
			FixedOrderComparator comparator = new FixedOrderComparator(emptyArray);
			assertTrue(true);
		} catch (IllegalArgumentException e) {
			fail("Exception was supposed to be thrown!");
		}
	}

}
