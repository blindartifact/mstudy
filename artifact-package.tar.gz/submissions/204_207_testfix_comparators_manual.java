package collections.comparators;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 *
 */
public class FixedOrderComparatorTest {

	@Test
	public void test() {
		try {
			Object[] nullArray = null;
			FixedOrderComparator comparator = new FixedOrderComparator(nullArray);
			fail("Exception was supposed to be thrown!");
		} catch (IllegalArgumentException e) {
			assertTrue(true);
		}
	}

}
