package math.genetics;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

public class ListPopulationTest {

	@Test
	public void test() throws Throwable {
		//only 1 percent of the population will be passed onto the next generation, population limit has been set to 1
		ElitisticListPopulation elitisticListPopulation0 = new ElitisticListPopulation(1, 1);
		
		//uses get chromosomes in listpopulation.java
		//empty list
		List<Chromosome> list0 = elitisticListPopulation0.getChromosomes();
		
		//create a new linked list of integers
		LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
		
		//creates a list of chromosomes 
		DummyListChromosome dummyListChromosome0 = new DummyListChromosome((List<Integer>) linkedList0);
		
		
		//set the chromosomes to an empty list
		elitisticListPopulation0.setChromosomes(list0);
		
		
		// Undeclared exception!
		try {
			//test fails here
			//shouldn't be able to add, but it does
			
			//how can i know what the intention of the test is?
			elitisticListPopulation0.addChromosome(dummyListChromosome0);
			fail("Expecting exception: UnsupportedOperationException");
		
		} catch(UnsupportedOperationException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}
}