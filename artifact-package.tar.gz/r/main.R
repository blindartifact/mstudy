## includes libs and utils (util.R)
source("util.R")

## Data location
BASE_DATA = "../"

DATASET_BASE= paste(BASE_DATA, "data/", sep="")

# Output Paths
GRAPHS_DIR = paste(BASE_DATA, "figures/", sep="")
dir.create(GRAPHS_DIR, showWarnings = FALSE)

TEX_GENERATED_FILES_DIR = paste(BASE_DATA, "generated_files/", sep="")
dir.create(TEX_GENERATED_FILES_DIR, showWarnings = FALSE)


# Submissions Data
SUBMISSIONS_CSV="submissions.csv"

# Survey Data
SURVEY_CSV="survey.csv"

# Test Correctness Analysis
TEST_CORRECTNESS_CSV="test_correctness.csv"

# User action timelines
TIMELINE_CSV="timeline.csv"
TIMELINE_ZIPS_CSV="actions_zips.csv"

# Rabbit data
RABBIT_FILE_DURATIONS_CSV="rabbit/fileEvent.csv"
RABBIT_RUN_EVENTS_CSV="rabbit/launchEvent.csv"

####################################################
## Load data
############

if(!exists("timeline_data")){
  timeline_data <<- loadCSV(TIMELINE_CSV)
  timeline_zips_data <<- loadCSV(TIMELINE_ZIPS_CSV)
  # sorted order
  timeline_data <<- sqldf('select * from timeline_data order by participantId, sessionId, actionId')
  timeline_zips_data <<- sqldf('select * from timeline_zips_data order by participantId, sessionId, actionId')
}

if(!exists("survey_data")){
  survey_data <<- loadCSV(SURVEY_CSV)
}

if(!exists("test_correctness")){
  test_correctness <<- loadCSV(TEST_CORRECTNESS_CSV)
  
  # The correct!=2 is just a sanity check, and is considered as invalid in our results (line 45)
  test_correctness <<- test_correctness[test_correctness$correct !=2,]
}

if(!exists("rabbit_file_timings")){
  rabbit_file_timings <<- loadCSV(RABBIT_FILE_DURATIONS_CSV)
}

if(!exists("grouped_events")){
  events = loadCSV(RABBIT_RUN_EVENTS_CSV)
  grouped_events <<- events %>% group_by(participantId, sessionId, launchModeId) %>% summarise(events=sum(count, na.rm=T)) %>% spread(launchModeId,events)
}

####################################################


prepareSubmissions <- function(){
  submissions <<- sqldf('select s.*, case when s.task_type="codefix" then s.java_status="passed" else ifnull(t.correct,0) end as fix_correct from submissions s left join test_correctness t on s.key=t.Session_ID')
  
  submissions <<- submissions %>% mutate(task_class=replace(task_class, task_class=="comparators", "comparator"))
  
  # make sure durations are doubles
  submissions$fix_duration <<- as.double(submissions$fix_duration)
  submissions$decision_duration <<- as.double(submissions$decision_duration)
  submissions$decision_inclusive_duration <<- as.double(submissions$decision_inclusive_duration)
  submissions$overall_duration <<- as.double(submissions$duration)
  
  submissions_with_surveys <<- sqldf('select s.*, v.* from submissions s left join survey_data v on s.participant_id = v."Please.enter.your.participant.ID"')
}

####################################################

if(!exists("submissions")){
  submissions <<- loadCSV(SUBMISSIONS_CSV)
  prepareSubmissions()
}


plotDurationBoxplot <- function(duration="decision_duration", facetByClass= FALSE, decisionCorrect=NA, fixCorrect=NA){
  
  # name of plot file
  plotfile = duration
  
  durations_data <- sqldf('select id, round(decision_inclusive_duration*1.0/60,2) as decision_duration, round(fix_duration*1.0/60,2) as fix_duration, round(overall_duration*1.0/60,2) as overall_duration, case when task_treatment="evosuite" then "Generated" when task_treatment="manual" then "Manual" end as  task_treatment, decision_correct, fix_correct, task_class, task_type from submissions')

  # Merged (All) data
  overall_data_per_task = sqldf('select id+1000 as id, round(decision_inclusive_duration*1.0/60,2) as decision_duration, round(fix_duration*1.0/60,2) as fix_duration, round(overall_duration*1.0/60,2) as overall_duration, case when task_treatment="evosuite" then "Generated" when task_treatment="manual" then "Manual" end as task_treatment, decision_correct, fix_correct, task_class, "All" as  task_type from submissions')
  overall_data_per_class = sqldf('select id+5000 as id, round(decision_inclusive_duration*1.0/60,2) as decision_duration, round(fix_duration*1.0/60,2) as fix_duration, round(overall_duration*1.0/60,2) as overall_duration, case when task_treatment="evosuite" then "Generated" when task_treatment="manual" then "Manual" end as task_treatment, decision_correct, fix_correct, "All" as task_class, task_type from submissions')
  overall_data_overall = sqldf('select id+10000 as id, round(decision_inclusive_duration*1.0/60,2) as decision_duration, round(fix_duration*1.0/60,2) as fix_duration, round(overall_duration*1.0/60,2) as overall_duration, case when task_treatment="evosuite" then "Generated" when task_treatment="manual" then "Manual" end as task_treatment, decision_correct, fix_correct, "All" as task_class, "All" as  task_type from submissions')
  durations_data <- rbind(durations_data,overall_data_per_task)
  durations_data <- rbind(durations_data,overall_data_per_class)
  durations_data <- rbind(durations_data,overall_data_overall)
  
  duration_melted <- melt(durations_data, id.vars=c("id",  "decision_duration", "fix_duration", "overall_duration", "task_treatment", "decision_correct", "fix_correct", "task_type"), measure.vars=c("task_class"))

  if(!is.na(decisionCorrect)){
    duration_melted <- duration_melted %>% filter(decision_correct==decisionCorrect)
    plotfile = paste(plotfile,"decision", ifelse(decisionCorrect==1, "correct", "incorrect"), sep = "_")
  }
  
  if(!is.na(fixCorrect)){
    duration_melted <- duration_melted %>% filter(fix_correct==fixCorrect)
    plotfile = paste(plotfile,"fix", ifelse(fixCorrect==1, "correct", "incorrect"), sep = "_")
  }
  
  #x<<-duration_melted
  
  # Base of the plot
  p = ggplot(duration_melted,aes(x=task_treatment,y=get(duration)))

  
  p = p  +
    geom_boxplot() + 
    scale_fill_brewer(palette = "Spectral") +
    theme(legend.position="bottom", text=element_text(size=22)) + 
    ylab("Duration (mins)") + 
    xlab("Treatment") 
  
  if(facetByClass){
    p = p + facet_grid(value~task_type)
    plotfile = paste(plotfile,"faceted", sep = "_")
  } else {
    p = p + facet_grid(~task_type)
  }

  # Add p-values to the plot
  if(facetByClass){
    if(is.na(decisionCorrect)){
      duration_comp = durations_comparisons
    } else {
      duration_comp = compareDurationsAll(submissions %>% filter(decision_correct == decisionCorrect))
    }
    
    if(is.na(fixCorrect)){
      duration_comp = durations_comparisons
    } else {
      duration_comp = compareDurationsAll(submissions %>% filter(fix_correct == fixCorrect))
    }
    
    p = p + scale_y_continuous(limits = c(0, 60))
    
    mask_dtype = duration_comp$duration == duration
    pvalue_dataset = duration_comp[mask_dtype,c("pvalue","class", "type")]
    colnames(pvalue_dataset) <- c("pvalue", "value", "task_type")
    
    #yval = 35
    #if(duration=="overall_duration")
      yval=55
    
    p = p + geom_text(data = pvalue_dataset %>% filter(pvalue>=0.05), aes(x=1.5, y=yval, label=paste("italic(p)==",round(pvalue, 3))),parse = TRUE, size=6)
    p = p + geom_text(data = pvalue_dataset %>% filter(pvalue<0.05), aes(x=1.5, y=yval, label=paste("italic(p)==",round(pvalue, 3),'*"*"')),parse = TRUE, size=6, fontface = "bold")
  }
  
  plot(p)
  
  savePlot(function(){
    plot(p)
  }, paste("boxplot", plotfile, sep="_"), 9, 9)
}


compareDurations <- function(dataset, t1="manual", t2="evosuite", vs_prepend="", duraton_col="decision_inclusive_duration"){
  ds = dataset
  
  mask_t1 = ds$"task_treatment" == t1 & !is.na(ds[[duraton_col]])
  mask_t2 = ds$"task_treatment" == t2 & !is.na(ds[[duraton_col]])
  
  list1 = ds[mask_t1,][[duraton_col]] * 1.0 / 60.0
  list2 = ds[mask_t2,][[duraton_col]] * 1.0 / 60.0
  
  t1_ratio = mean(list1,na.rm = T)
  t2_ratio = mean(list2,na.rm = T)
  
  wil_res = wilcox.test(list1,list2)
  pval=wil_res$p.value
  
  
  if (pval < 0.05 && t1_ratio > t2_ratio) {
    comparison_result = "sigbetter"
  } else if (t1_ratio > t2_ratio) {
    comparison_result = "better"
  } else if (pval < 0.05 && t2_ratio > t1_ratio) {
    comparison_result = "sigworse"
  } else if (t2_ratio > t1_ratio) {
    comparison_result = "worse"
  } else {
    comparison_result = "equal"
  }
  
  comparison = data.table(
    vs=paste(vs_prepend , duraton_col, " - ", paste(t1,"vs",t2), sep=""), 
    ratio1=t1_ratio,
    ratio2=t2_ratio, 
    pvalue=as.numeric(pval),
    verdict=comparison_result
  )
  
  return (comparison)
}


# Fisher test for comparing the correctness of decisions/fixes
compareCorrectness <- function(dataset, t1="manual", t2="evosuite", vs_prepend="", correct_col="decision_correct"){
    ds = dataset
  
    mask_t1 = ds$"task_treatment" == t1 & !is.na(ds[[correct_col]])
    mask_t2 = ds$"task_treatment" == t2 & !is.na(ds[[correct_col]])
    
    if(nrow(ds[mask_t1,])==0 || nrow(ds[mask_t2,])==0){
      print(paste("missing: " , "either t1 or t2"))
      next
    }
    
    t1_correct = nrow(ds[mask_t1 & ds[[correct_col]] == "1",])
    t2_correct = nrow(ds[mask_t2 & ds[[correct_col]] == "1",])
    
    t1_total = nrow(ds[mask_t1,])
    t2_total = nrow(ds[mask_t2,])
    
    data = matrix(c(t1_correct, t1_total - t1_correct, t2_correct, t2_total - t2_correct), ncol=2, nrow=2)
    
    fish = fisher.test(data)
    
    t1_ratio = mean(ds[mask_t1,][[correct_col]])
    t2_ratio = mean(ds[mask_t2,][[correct_col]])
   
    if (fish$p.value < 0.05 && t1_ratio > t2_ratio) {
      comparison_result = "sigbetter"
    } else if (t1_ratio > t2_ratio) {
      comparison_result = "better"
    } else if (fish$p.value < 0.05 && t2_ratio > t1_ratio) {
      comparison_result = "sigworse"
    } else if (t2_ratio > t1_ratio) {
      comparison_result = "worse"
    } else {
      comparison_result = "equal"
    }
    
    comparison = data.table(
      vs=paste(vs_prepend , correct_col, " - ", paste(t1,"vs",t2), sep=""), 
      t1_correct=t1_correct,
      t1_total=t1_total,
      t2_correct=t2_correct,
      t2_total=t2_total,
      ratio1=t1_ratio,
      ratio2=t2_ratio, 
      pvalue=as.numeric(fish$p.value),
      verdict=comparison_result
    )
  
    return (comparison)
}

compareDurationsAll <- function(subs){
  
  duration_types = c('decision_duration', 'fix_duration', 'overall_duration')
  
  durations =                compareDurations(subs)
  durations$class = "All"
  durations$type = "All"
  durations$duration = "All"
  durations = durations[-1,]
  
  for (d_type in duration_types){
    
    if(d_type=="decision_duration"){
      d_col = "decision_inclusive_duration"
    } else {
      d_col = d_type
    }

    tmp =                    compareDurations(subs,,,,d_col)
    tmp$class = "All"
    tmp$type = "All"
    tmp$duration = d_type
    durations = rbind(durations, tmp)
    
    
    for(type in unique(subs$task_type)){
      tmp = compareDurations(subs[subs$task_type==type,],,,paste(type, "- "), d_col)
      tmp$class = "All"
      tmp$type = type
      tmp$duration = d_type
      durations = rbind(durations, tmp)
    }
    for(class in unique(subs$task_class)){
      
      tmp = compareDurations(subs[subs$task_class==class,],,,paste(class, "- "), d_col)
      tmp$class = class
      tmp$type = "All"
      tmp$duration = d_type
      durations = rbind(durations, tmp)
      
      for(type in unique(subs$task_type)){
        tmp = compareDurations(subs[subs$task_class==class & subs$task_type==type,],,,paste(class, "-", type, "- "), d_col)
        tmp$class = class
        tmp$type = type
        tmp$duration = d_type
        durations = rbind(durations, tmp)
      }
    }
  }
  
  #durations_comparisons <<- durations
  return(durations)
}

compareDecisionsAll <- function(subs){
  
  decisions =                    compareCorrectness(subs)
  decisions$class = "All"
  decisions$type = "All"

  for(type in sort(unique(subs$task_type))){
    tmp = compareCorrectness(subs[subs$task_type==type,],,,paste(type, "- "))
    tmp$class = "All"
    tmp$type = type
    decisions = rbind(decisions, tmp)
  }
  for(class in sort(unique(subs$task_class))){
    
    tmp = compareCorrectness(subs[subs$task_class==class,],,,paste(class, "- "))
    tmp$class = class
    tmp$type = "All"
    decisions = rbind(decisions, tmp)
    
    for(type in sort(unique(subs$task_type))){
      tmp = compareCorrectness(subs[subs$task_class==class & subs$task_type==type,],,,paste(class, "-", type, "- "))
      tmp$class = class
      tmp$type = type
      decisions = rbind(decisions, tmp)
    }
  }
  
  return(decisions)
}

compareFixesAll <- function(subs){
 
  decisions =                    compareCorrectness(subs,,,,"fix_correct")
  decisions$class = "All"
  decisions$type = "All"
  
  for(type in sort(unique(subs$task_type))){
    tmp = compareCorrectness(subs[subs$task_type==type,],,,paste(type, "- "),"fix_correct")
    tmp$class = "All"
    tmp$type = type
    decisions = rbind(decisions, tmp)
  }
  for(class in sort(unique(subs$task_class))){
    
    tmp = compareCorrectness(subs[subs$task_class==class,],,,paste(class, "- "),"fix_correct")
    tmp$class = class
    tmp$type = "All"
    decisions = rbind(decisions, tmp)
    
    for(type in sort(unique(subs$task_type))){
      tmp = compareCorrectness(subs[subs$task_class==class & subs$task_type==type,],,,paste(class, "-", type, "- "),"fix_correct")
      tmp$class = class
      tmp$type = type
      decisions = rbind(decisions, tmp)
    }
  }
  
  return(decisions)
}

decisionsTable <- function(){
  TABLE = paste(TEX_GENERATED_FILES_DIR,"/tableDecisionsComparison.tex",sep="")
  unlink(TABLE)
  sink(TABLE, append=TRUE, split=TRUE)  
  
  cat("\\begin{tabular}{ llrrc }\\toprule","\n")
  cat("Task type & Task class & \\multicolumn{1}{c}{Manual} & \\multicolumn{1}{c}{Generated} & \\multicolumn{1}{c}{\\emph{p}-val.} \\\\","\n")
  cat("\\midrule","\n")
  
  
  i=0
  for(i in 1:nrow(decisions_comparisons)){
    comparison = decisions_comparisons[i,]
    
    if(comparison$class!="All")
      mask_class = submissions$task_class==comparison$class
    else 
      mask_class = T
    
    if(comparison$type!="All")
      mask_type = submissions$task_type==comparison$type
    else 
      mask_type = T
    
    cat(comparison$type)
    
    cat(" & ", comparison$class,sep="")
    
    
    
    cat(" & ",paste(comparison$t1_correct, comparison$t1_total,sep="/"),sep="")
    cat(wrapTex(paste(" (", getPercentX(comparison$ratio1*100), ")", sep=""),,,comparison$verdict=="sigbetter" || comparison$verdict=="better"))
    cat(paste(" [",nrow(submissions[mask_class & mask_type & submissions$task_treatment=="manual" & submissions$decision=="dontknow",]),"]",sep=""))
    
    cat(" & ",paste(comparison$t2_correct, comparison$t2_total,sep="/"),sep="")
    cat(wrapTex(paste(" (", getPercentX(comparison$ratio2*100), ")", sep=""),,,comparison$verdict=="sigworse" || comparison$verdict=="worse"))
    
    
    cat(paste(" [",nrow(submissions[mask_class & mask_type & submissions$task_treatment=="evosuite" & submissions$decision=="dontknow",]),"]",sep=""))
    #cat(" & ",comparison$verdict,sep="")
    
    cat(" & ",niceprint(comparison$pvalue,2),sep="")
    
    cat(" \\\\ \n")
    
    if (i == nrow(decisions_comparisons))
      cat("\\bottomrule","\n")
    i = i + 1
  }
  
  cat("\\end{tabular}","\n")
  
  sink()
  
}


fixesTable <- function(fixes_comparison_df, texFile="tableFixesComparison.tex"){
  TABLE = paste(TEX_GENERATED_FILES_DIR,"/", texFile,sep="")
  unlink(TABLE)
  sink(TABLE, append=TRUE, split=TRUE)  
  
  cat("\\begin{tabular}{ llrrc }\\toprule","\n")
  cat("Task type & Task class & \\multicolumn{1}{c}{Manual} & \\multicolumn{1}{c}{Generated} & \\multicolumn{1}{c}{\\emph{p}-val.} \\\\","\n")
  cat("\\midrule","\n")
  
  i=0
  for(i in 1:nrow(fixes_comparison_df)){
    comparison = fixes_comparison_df[i,]
    
    cat(comparison$type)
    
    cat(" & ", comparison$class,sep="")
    
    
    
    cat(" & ",paste(comparison$t1_correct, comparison$t1_total,sep="/"),sep="")
    cat(wrapTex(paste(" (", getPercentX(comparison$ratio1*100), ")", sep=""),,,comparison$verdict=="sigbetter" || comparison$verdict=="better"))
    if(comparison$verdict=="sigbetter"){
      cat(wrapTex("*"))
    }
    cat(" & ",paste(comparison$t2_correct, comparison$t2_total,sep="/"),sep="")
    cat(wrapTex(paste(" (", getPercentX(comparison$ratio2*100), ")", sep=""),,,comparison$verdict=="sigworse" || comparison$verdict=="worse"))
    if(comparison$verdict=="sigworse"){
      cat(wrapTex("*"))
    }

    cat(" & ",niceprint(comparison$pvalue,2),sep="")
    
    cat(" \\\\ \n")
    
    if (i == nrow(fixes_comparison_df))
      cat("\\bottomrule","\n")
    i = i + 1
  }
  
  cat("\\end{tabular}","\n")
  
  sink()
}

measureTimePerFile <- function(){
  time_on_test = rabbit_file_timings %>% filter(filePath %like% "/test/") %>% group_by(participantId, sessionId) %>% summarise(test_duration=sum(duration))
  time_on_src = rabbit_file_timings %>% filter(filePath %like% "/src/") %>% group_by(participantId, sessionId) %>% summarise(src_duration=sum(duration))

  
  submissions_with_fileview_timings <<- left_join(submissions, time_on_test, by=c("participant_id"="participantId", "session_id"="sessionId")) %>% left_join(., time_on_src, by=c("participant_id"="participantId", "session_id"="sessionId"))
}

macroFile <- function(){

  FILE = paste(TEX_GENERATED_FILES_DIR,"macroFile.tex",sep="")
  unlink(FILE)
  sink(FILE, append=TRUE, split=TRUE)
  
  
  NumParticipants = length(unique(submissions$participant_id))
  printMacro("NumParticipants", NumParticipants)
  
  for(tag in unique(submissions$participant_tag)){
    printMacro(paste("NumParticipants",chartr("12","AB",tag),sep = ""), length(unique(submissions[submissions$participant_tag==tag,]$participant_id)))
  }
  
  # file timings
  submissions_per_treatment_and_type = submissions %>% group_by(task_treatment, task_type)  
  submissions_per_treatment = submissions %>% group_by(task_treatment, task_type="all")  
  submissions_per_type = submissions %>% group_by(task_treatment="all", task_type) 
  submissions_all = submissions %>% group_by(task_treatment="all", task_type="all")
  
  submissions_overall <<- submissions_per_treatment_and_type %>% union(submissions_per_treatment) %>% union(submissions_per_type) %>% union(submissions_all)
  
  durations = sqldf('select id, round(decision_inclusive_duration*1.0/60,2) as decision_duration, round(fix_duration*1.0/60,2) as fix_duration, round(overall_duration*1.0/60,2) as overall_duration, task_treatment, decision_correct, task_class, task_type from submissions')
  
  for(treat in unique(durations$task_treatment)){
    printMacro(paste("meanOverallDuration", toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat,]$overall_duration,na.rm=T)))
    printMacro(paste("medianOverallDuration", toupper(getTreatmentName(treat)),sep=""), timePrintMins(median(durations[durations$task_treatment==treat,]$overall_duration,na.rm=T)))
    printMacro(paste("meanDecisionDuration", toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat,]$decision_duration,na.rm=T)))
    printMacro(paste("medianDecisionDuration", toupper(getTreatmentName(treat)),sep=""), timePrintMins(median(durations[durations$task_treatment==treat,]$decision_duration,na.rm=T)))
    printMacro(paste("meanFixDuration", toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat,]$fix_duration,na.rm=T)))
    for(task in unique(durations$task_type)){
      printMacro(paste("meanOverallDuration", task, toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task,]$overall_duration,na.rm=T)))
      printMacro(paste("meanDecisionDuration", task, toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task,]$decision_duration,na.rm=T)))
      printMacro(paste("meanFixDuration",task, toupper(getTreatmentName(treat)),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task,]$fix_duration,na.rm=T)))
      for(class in unique(durations$task_class)){
        printMacro(paste("meanOverallDuration",task, toupper(getTreatmentName(treat)), tolower(class),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task & durations$task_class==class,]$overall_duration,na.rm=T)))
        printMacro(paste("meanDecisionDuration",task, toupper(getTreatmentName(treat)), tolower(class),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task & durations$task_class==class,]$decision_duration,na.rm=T)))
        printMacro(paste("meanFixDuration",task, toupper(getTreatmentName(treat)) , tolower(class),sep=""), timePrintMins(mean(durations[durations$task_treatment==treat & durations$task_type==task & durations$task_class==class,]$fix_duration,na.rm=T)))
      }
    }
  }
  
  # How much (%) longer it takes with generated vs manual -- overall
  meanGenDuration = mean(durations[durations$task_treatment=="evosuite",]$overall_duration,na.rm=T)
  meanManDuration = mean(durations[durations$task_treatment=="manual",]$overall_duration,na.rm=T)
  durationDiff = meanGenDuration - meanManDuration
  
  printMacro("durationIncreaseRatioManGen", getPercentX(durationDiff*100.0/meanManDuration))
  
  # How much (%) longer it takes with exception (comparators-testfix-manual, listpopulation-testfix-generated)
  #   vs no exception (comparators-testfix-generated, listpopulation-testfix-manual)
  meanExDuration = mean(durations[durations$task_class=="comparator" & durations$task_type=="testfix" & durations$task_treatment=="manual",]$fix_duration,na.rm=T)
  meanNoExDuration = mean(durations[durations$task_class=="comparator" & durations$task_type=="testfix" & durations$task_treatment=="evosuite",]$fix_duration,na.rm=T)
  durationDiffcomp = meanExDuration - meanNoExDuration

  durationIncreaseRatioExcomparators = durationDiffcomp*100.0/meanNoExDuration
  
  printMacro("durationIncreaseRatioExcomparators", getPercentX(durationIncreaseRatioExcomparators))
  
  meanExDuration = mean(durations[durations$task_class=="listpopulation" & durations$task_type=="testfix" & durations$task_treatment=="evosuite",]$fix_duration,na.rm=T)
  meanNoExDuration = mean(durations[durations$task_class=="listpopulation" & durations$task_type=="testfix" & durations$task_treatment=="manual",]$fix_duration,na.rm=T)
  durationDifflist = meanExDuration - meanNoExDuration

  durationIncreaseRatioExlistpopulation = durationDifflist*100.0/meanNoExDuration
  
  printMacro("durationIncreaseRatioExlistpopulation", getPercentX(durationIncreaseRatioExlistpopulation))
  
  printMacro("durationIncreaseRatioExmean", getPercentX(mean(c(durationIncreaseRatioExcomparators, durationIncreaseRatioExlistpopulation))))
  
  printMacro("durationIncreaseExmean", timePrintMins(mean(c(durationDiffcomp, durationDifflist))))
  
  printMacro("decisionsCorrectAll", (submissions %>% summarise(correct=sum(decision_correct)))$correct)
  
  for(class in unique(decisions_comparisons$class)){
    for(type in unique(decisions_comparisons$type)){
      mask_ct = decisions_comparisons$class == class & decisions_comparisons$type == type
      printMacro(paste("decisionsCorrectManual", toupper(type), tolower(class),sep=""), decisions_comparisons[mask_ct,][1]$t1_correct)
      printMacro(paste("decisionsTotalManual", toupper(type), tolower(class),sep=""), decisions_comparisons[mask_ct,][1]$t1_total)
      printMacro(paste("decisionsRatioManual", toupper(type), tolower(class),sep=""), getPercentX(decisions_comparisons[mask_ct,][1]$ratio1*100.0))
      
      printMacro(paste("decisionsCorrectGenerated", toupper(type), tolower(class),sep=""), decisions_comparisons[mask_ct,][1]$t2_correct)
      printMacro(paste("decisionsTotalGenerated", toupper(type), tolower(class),sep=""), decisions_comparisons[mask_ct,][1]$t2_total)
      printMacro(paste("decisionsRatioGenerated", toupper(type), tolower(class),sep=""), getPercentX(decisions_comparisons[mask_ct,][1]$ratio2*100.0))
    }
  }
  
  for(class in unique(fixes_comparisons$class)){
    for(type in unique(fixes_comparisons$type)){
      mask_ct = fixes_comparisons$class == class & fixes_comparisons$type == type
      printMacro(paste("fixesCorrectManual", toupper(type), tolower(class),sep=""), fixes_comparisons[mask_ct,][1]$t1_correct)
      printMacro(paste("fixesTotalManual", toupper(type), tolower(class),sep=""), fixes_comparisons[mask_ct,][1]$t1_total)
      printMacro(paste("fixesRatioManual", toupper(type), tolower(class),sep=""), getPercentX(fixes_comparisons[mask_ct,][1]$ratio1*100.0))
      
      printMacro(paste("fixesCorrectGenerated", toupper(type), tolower(class),sep=""), fixes_comparisons[mask_ct,][1]$t2_correct)
      printMacro(paste("fixesTotalGenerated", toupper(type), tolower(class),sep=""), fixes_comparisons[mask_ct,][1]$t2_total)
      printMacro(paste("fixesRatioGenerated", toupper(type), tolower(class),sep=""), getPercentX(fixes_comparisons[mask_ct,][1]$ratio2*100.0))
    }
  }
  
  # Duration medians
  duration_medians = submissions_overall %>% group_by(task_treatment, task_type) %>% summarise(decision_duration=timePrintMins(median(decision_inclusive_duration)/60.0), overall_duration=timePrintMins(median(overall_duration)/60.0))
  for(i in 1:nrow(duration_medians)){
    row = duration_medians[i,]
    printMacro(paste("medianDecisionDuration",toupper(getTreatmentName(row$task_treatment)),tolower(row$task_type),sep=""), row$decision_duration)
    printMacro(paste("medianOverallDuration",toupper(getTreatmentName(row$task_treatment)),tolower(row$task_type),sep=""), row$overall_duration)
  }
  
  duration_medians_class = submissions_overall %>% group_by(task_treatment, task_type, task_class) %>% summarise(decision_duration=timePrintMins(median(decision_inclusive_duration)/60.0), overall_duration=timePrintMins(median(overall_duration)/60.0))
  for(i in 1:nrow(duration_medians_class)){
    row = duration_medians_class[i,]
    printMacro(paste("medianDecisionDuration",toupper(getTreatmentName(row$task_treatment)),tolower(row$task_type), toupper(row$task_class),sep=""), row$decision_duration)
    printMacro(paste("medianOverallDuration",toupper(getTreatmentName(row$task_treatment)),tolower(row$task_type), toupper(row$task_class),sep=""), row$overall_duration)
  }
  
  # Action-counts
  submissions_with_actions=left_join(submissions, submissions_timeline, by=c("participant_id"="pid", "session_id"="sid"))
  
  actions_overall = submissions_with_actions
  actions_taskTreatment = submissions_with_actions %>% group_by(task_treatment)
  actions_taskClass = submissions_with_actions %>% group_by(task_class)
  actions_taskType = submissions_with_actions %>% group_by(task_type)
  
  actionsList = list(overall=actions_overall, taskTreatment=actions_taskTreatment, taskClass=actions_taskClass, taskType=actions_taskType)
  
  for(name in names(actionsList)){ 
    x = actionsList[[name]]
    actions =  x %>% summarise(
      total=sum(before,after, na.rm=T), 
      bruns=sum(brun, na.rm=T),
      aruns=sum(arun, na.rm=T),
      total_runs=sum(bruns+aruns, na.rm=T),
      bsaves=sum(bsave, na.rm=T),
      asaves=sum(asave, na.rm=T),
      total_saves=sum(bsaves+asaves, na.rm=T),
      save_to_run_ratio=total_saves/total_runs,
      before_ratio=sum(before,na.rm=T)*100.0/total,
      after_ratio=sum(after,na.rm=T)*100.0/total,
      bruns_ratio=bruns*100.0/(total_runs),
      aruns_ratio=aruns*100.0/(total_runs),
      bsaves_ratio=bsaves*100.0/(total_saves),
      asaves_ratio=asaves*100.0/(total_saves))

    dfType = toupper(name)
    if(dfType=="OVERALL"){
      printMacro(paste("actionsBeforeRatio", dfType, sep=""), getPercentX(actions$before_ratio))
      printMacro(paste("actionsAfterRatio", dfType, sep=""), getPercentX(actions$after_ratio))
      
      printMacro(paste("actionsBeforeSavesRatio", dfType,sep=""), getPercentX(actions$bsaves_ratio,1))
      printMacro(paste("actionsAfterSavesRatio", dfType,sep=""), getPercentX(actions$asaves_ratio,1))
      
      printMacro(paste("actionsBeforeRunsRatio", dfType,sep=""), getPercentX(actions$bruns_ratio,1))
      printMacro(paste("actionsAfterRunsRatio", dfType,sep=""), getPercentX(actions$aruns_ratio,1))
      
      printMacro(paste("actionsSaveToRunRatio", dfType, sep=""), getPercentX(actions$save_to_run_ratio,2))
    } else {
      for(i in 1:nrow(actions)){
        actionsGroup = actions[i,]
        printMacro(paste("actionsBeforeRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$before_ratio,1))
        printMacro(paste("actionsAfterRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$after_ratio,1))
        
        printMacro(paste("actionsBeforeSavesRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$bsaves_ratio,1))
        printMacro(paste("actionsAfterSavesRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$asaves_ratio,1))
        
        printMacro(paste("actionsBeforeRunsRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$bruns_ratio,1))
        printMacro(paste("actionsAfterRunsRatio", dfType, tolower(actionsGroup[1]),sep=""), getPercentX(actionsGroup$aruns_ratio,1))
        
        printMacro(paste("actionsSaveToRunRatio", dfType, tolower(actionsGroup[1]), sep=""), getPercentX(actionsGroup$save_to_run_ratio, 2))
      }
    }
  }
  
  # file timings
  file_timings_per_treatment_and_type = submissions_with_fileview_timings %>% group_by(task_treatment, task_type)  
  file_timings_per_treatment = submissions_with_fileview_timings %>% group_by(task_treatment, task_type="all")  
  file_timings_per_type = submissions_with_fileview_timings %>% group_by(task_treatment="all", task_type) 
  file_timings_all = submissions_with_fileview_timings %>% group_by(task_treatment="all", task_type="all")
  
  file_timings <<- file_timings_all %>% union(file_timings_per_type) %>% union(file_timings_per_treatment) %>% union(file_timings_per_treatment_and_type) %>%
    summarise(time_total=sum(src_duration+test_duration, na.rm=T), src_total=sum(src_duration, na.rm=T), test_total=sum(test_duration, na.rm=T), src_ratio=src_total*100/time_total, test_ratio=test_total*100/time_total)
  
  for(i in 1:nrow(file_timings)){
    t=file_timings[i,]
    printMacro(paste("timingsSrc", toupper(getTreatmentName(t$task_treatment)), tolower(t$task_type), sep=""), getPercentX(t$src_ratio, 1))
    printMacro(paste("timingsTest", toupper(getTreatmentName(t$task_treatment)), tolower(t$task_type), sep=""), getPercentX(t$test_ratio, 1))
  }
  #print(file_timings %>% select(task_treatment, task_type, src_ratio, test_ratio ))
  
  # Users who used debug / coverage
  submissions_with_rabbit_events <<- left_join(submissions, grouped_events, by=c("participant_id"="participantId", "session_id"="sessionId"))
  
  sessionsUsedDebugger = submissions_with_rabbit_events %>% filter(!is.na(debug)) %>% distinct(session_id) %>% tally()
  printMacro("numSessionsUsedDebugger", sessionsUsedDebugger$n)
  
  numSessionsUsedDebuggerFixCorrect = submissions_with_rabbit_events %>% filter(!is.na(debug) & fix_correct==1) %>% tally()
  printMacro("numSessionsUsedDebuggerFixCorrect", numSessionsUsedDebuggerFixCorrect$n)
  printMacro("numSessionsUsedDebuggerFixCorrectRatio", getPercentX(numSessionsUsedDebuggerFixCorrect$n*100.0/sessionsUsedDebugger$n))
  
  overallFixCorrectRatio = getPercentX((submissions %>% filter(fix_correct==1) %>% tally())$n*100.0/nrow(submissions))
  printMacro("overallFixCorrectRatio", overallFixCorrectRatio)
  
  participantsUsedDebugger = submissions_with_rabbit_events %>% filter(!is.na(debug)) %>% distinct(participant_id) %>% tally()
  printMacro("numParticipantsUsedDebugger", participantsUsedDebugger$n)
  
  sessionsUsedCoverage = submissions_with_rabbit_events %>% filter(!is.na(coverage)) %>% distinct(session_id) %>% tally()
  printMacro("numSessionsUsedCoverage", sessionsUsedCoverage$n)
  
  participantsUsedCoverage = submissions_with_rabbit_events %>% filter(!is.na(coverage)) %>% distinct(participant_id) %>% tally()
  printMacro("numParticipantsUsedCoverage", participantsUsedCoverage$n)
  
  sink()
  
}

# Get treatment name substitutions
getTreatmentName <- function(name){
  if(tolower(as.character(name)) == "evosuite") return("Generated")
  if(tolower(as.character(name)) == "manual") return("Manual")
  return(name)
}

# Get clean survey question substitutions
getSurveyQuestion <- function(item){
  
  #testfix
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...The.task.was.clear..") 
    return("1.The task was clear")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...I.had.enough.time.to.finish.the.task..")
    return("2.I had enough time to finish the task")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...It.was.easy.to.identify.the.bug..")
    return("3.It was easy to identify the bug")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...It.was.easy.to.fix.the.bug..")
    return("4.It was easy to fix the bug")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...I.am.certain.my.test.fix.is.correct..")
    return("5.I am certain my test fix is correct")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...The.class.was.easy.to.understand..")
    return("6.The class was easy to understand")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...The.unit.test.was.easy.to.understand..")
    return("7.The unit test was easy to understand")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.a.unit.test.code..please.specify.your.level.of.agreement...I.am.certain.I.produced.a.good.fixed.unit.test..")
    return("8.I am certain I produced a good fixed unit test")
  
  #codefix
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...The.task.was.clear..") 
    return("1.The task was clear")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...I.had.enough.time.to.finish.the.task..")
    return("2.I had enough time to finish the task")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...It.was.easy.to.identify.the.bug..")
    return("3.It was easy to identify the bug")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...It.was.easy.to.fix.the.bug..")
    return("4.It was easy to fix the bug")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...I.am.certain.my.code.fix.is.correct..")
    return("5.I am certain my code fix is correct")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...The.class.was.easy.to.understand..")
    return("6.The class was easy to understand")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...The.unit.test.was.easy.to.understand..")
    return("7.The unit test was easy to understand")
  if(item == "For.each.of.the.following.questions.about.the.part.of.the.study.where.you.had.to.fix.source.code..please.specify.your.level.of.agreement...The.unit.test.was.useful.to.fix.the.bug.in.the.class..")
    return("8.The test was useful to fix the bug in the class")
  else
    return(item)
}


prepareSurveyLikert <- function(codefix=T, testfix=F){
  # Select columns related only to codefix or testfix
  cols = c()
  if(codefix)
    cols = c(cols, colnames(survey_data[c(14:21)]))
  if(testfix)
    cols = c(cols, colnames(survey_data[c(26:33)]))
  
  treatments = c("manual", "evosuite")
  
  results = data.table(
    Group=character(),
    Item=character(),
    "Fully disagree"=numeric(),
    "Partially disagree"=numeric(),
    "Neither agree nor disagree"=numeric(),
    "Partially agree"=numeric(),
    "Fully agree"=numeric()
  )
  
  ds = submissions_with_surveys
  
  mask_codefix = ds$"task_type" == "codefix"
  mask_testfix = ds$"task_type" == "testfix"
  
  if(codefix != testfix){
    if(codefix)
      ds = ds[mask_codefix,]
    if(testfix)
      ds = ds[mask_testfix,]
  }
  
  # Subset only columns relevant to testfix/codefix
  ds_sub = ds[,c(cols)]
  
  
  for(col in cols){
    names(ds_sub)[names(ds_sub)==col] <- getSurveyQuestion(col)
  }
  
  
  # Force factor levels
  mylevels <- c('Fully disagree', 'Partially disagree', 'Neither', 'Partially agree', 'Fully agree')
  ds_sub[ds_sub=="Neither agree nor disagree"] <- "Neither"
  for(i in seq_along(ds_sub)) {
    ds_sub[,i] <- factor(ds_sub[,i], levels=mylevels)
  }
  
  # replace treatment names with proper names
  for(t in treatments){
    ds$task_treatment[ds$task_treatment == t] <- getTreatmentName(t)
  }
  
  likert_data = likert(ds_sub, grouping = ds$task_treatment)
  
  return(likert_data)
}

plotLikertSurveys <- function(){
  
  savePlot(function(){
    p = prepareSurveyLikert(T,F)
    the_plot = plot(p, text.size=4) + theme(axis.text=element_text(size=12), strip.text=element_text(size=12))
    plot(the_plot)
  }, paste("likert", "survey","codefix",sep="_"), 7, 9.5)
  
  savePlot(function(){
    p = prepareSurveyLikert(F,T)
    the_plot = plot(p, text.size=4) + theme(axis.text=element_text(size=12), strip.text=element_text(size=12))
    plot(the_plot)
  }, paste("likert", "survey","testfix",sep="_"), 7, 9.5)
}

# Reset environment
resetData <-function(){
  remove(survey_data, test_correctness, submissions, submissions_with_surveys, decisions_comparisons, durations_comparisons, fixes_comparisons, pos = ".GlobalEnv")
}

userActionTimeline <- function(){
  
  results = data.table(
    pid=numeric(), 
    sid=numeric(), 
    before=numeric(),
    after=numeric(),
    brun=numeric(),
    bsave=numeric(),
    arun=numeric(),
    asave=numeric()
  )
  
  
  for(i in 1:nrow(submissions)){
    sub = submissions[i,]
    
    td = timeline_data[timeline_data$participantId==sub$participant_id & timeline_data$sessionId==sub$session_id,]
    td2 = timeline_zips_data[timeline_zips_data$participantId==sub$participant_id & timeline_zips_data$sessionId==sub$session_id,]
    if(nrow(td2) == 0){
      if(nrow(td) == 0){
        next
      } else {
        td2 = td
      }
    }
    tdata = td2
    
    numBefore = 0
    numAfter = 0
    
    numBeforeSave = 0
    numBeforeRun = 0
    
    numAfterSave = 0
    numAfterRun = 0
    
    for(j in 1:nrow(tdata)){
      td = tdata[j,]
      
      diff = as.integer(difftime(td$timestamp, sub$decision_end, unit="secs"))
      
      if(diff<=0){
        numBefore = numBefore + 1
        
        if(td$action=="junitrun"){
          numBeforeRun = numBeforeRun + 1
        } else if(td$action=="saved") {
          numBeforeSave = numBeforeSave + 1
        } else {
          print("this shouldn't happen!")
        }
      } else {
        numAfter = numAfter + 1
        
        if(td$action=="junitrun"){
          numAfterRun = numAfterRun + 1
        } else if(td$action=="saved") {
          numAfterSave = numAfterSave + 1
        } else {
          print("this shouldn't happen!")
        }
      }
    }
    #print(paste(numBefore, numAfter))
    
    results = rbind(results,data.table(
      pid=sub$participant_id, 
      sid=sub$session_id, 
      before=numBefore,
      after=numAfter,
      brun=numBeforeRun,
      bsave=numBeforeSave,
      arun=numAfterRun,
      asave=numAfterSave
    ))
    
  }
  submissions_timeline <<- results
}

# Main function
doMagic <- function(){
  options(warn=-1)
  cat("----------------------\n#### Analysing Data ...\n----------------------\n")
  # Analysis Functions
  if(!exists("decisions_comparisons")){
    decisions_comparisons <<- compareDecisionsAll(submissions)
  }
  if(!exists("durations_comparisons")){
    durations_comparisons <<- compareDurationsAll(submissions)
  }
  if(!exists("fixes_comparisons")){
    fixes_comparisons <<- compareFixesAll(submissions)
  }
  if(!exists("submissions_timeline")){
    userActionTimeline()
  }
  if(!exists("submissions_with_fileview_timings")){
    measureTimePerFile()
  }
  
  # Figures
  cat("#### Plotting Duration Boxplots ...\n----------------------\n")
  plotDurationBoxplot("decision_duration", TRUE)

  plotDurationBoxplot("overall_duration", TRUE)
  
  cat("#### Plotting Survey Analysis ...\n----------------------\n")
  plotLikertSurveys()
  
  # Tables
  cat("#### Generating Tables ...\n----------------------\n")
  decisionsTable()
  fixesTable(fixes_comparisons)
  
  # Macros
  cat("\n----------------------\n#### Generating MacroFile Analysis ...\n----------------------\n")
  macroFile()
  
  cat("\n----------------------\n### Finished!\n----------------------\n\t_______________________________________________________________\n\n=========> Please see the folders 'figures' and 'generated_files'. <=========\n\t_______________________________________________________________\n\n")
}
doMagic()

# EOF

